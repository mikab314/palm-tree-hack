import TrainingCenter from './TrainingCenter'

function App() {
  return (
    <TrainingCenter />
  )
}

export default App
